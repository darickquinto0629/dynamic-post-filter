<?php
/**
 * All Menu Filter Shortcode
 *
 * @package All_Menu_Filter
 */

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_shortcode( 'all-menu', 'all_menu_callback' );

/**
 * Shortcode callback for [all-menu]
 *
 * @param array $atts Shortcode attributes
 * @return string HTML output
 */
function all_menu_callback( $atts ) {
	// Parse shortcode attributes with defaults
	$atts = shortcode_atts(
		array(
			'post_type'      => 'post',      // Default post type
			'posts_per_page' => -1,
			'orderby'        => 'date',
			'order'          => 'DESC',
			'taxonomy'       => '',          // Custom taxonomy
			'term'           => '',          // Term to filter by
		),
		$atts,
		'all-menu'
	);

	// Generate unique ID for this shortcode instance
	$unique_id = 'all-menu-' . uniqid();

	// Enqueue scripts
	wp_enqueue_script( 'jquery' );
	wp_enqueue_script(
		'all-menu-filter',
		ALL_MENU_FILTER_URL . 'js/all-menu-filter.js',
		array( 'jquery' ),
		ALL_MENU_FILTER_VERSION,
		true
	);

	// Localize script with AJAX URL and nonce
	wp_localize_script(
		'all-menu-filter',
		'all_menu_data',
		array(
			'ajax_url' => admin_url( 'admin-ajax.php' ),
			'nonce'    => wp_create_nonce( 'all_menu_nonce' ),
		)
	);

	// Get all terms for the taxonomy if specified
	$terms = array();
	if ( ! empty( $atts['taxonomy'] ) ) {
		$terms = get_terms(
			array(
				'taxonomy'   => sanitize_text_field( $atts['taxonomy'] ),
				'hide_empty' => true,
			)
		);
	}

	// Build WP_Query arguments
	$query_args = array(
		'post_type'      => sanitize_text_field( $atts['post_type'] ),
		'posts_per_page' => intval( $atts['posts_per_page'] ),
		'orderby'        => sanitize_text_field( $atts['orderby'] ),
		'order'          => sanitize_text_field( $atts['order'] ),
	);

	// Add taxonomy filter if specified
	if ( ! empty( $atts['taxonomy'] ) && ! empty( $atts['term'] ) ) {
		$query_args['tax_query'] = array(
			array(
				'taxonomy' => sanitize_text_field( $atts['taxonomy'] ),
				'field'    => 'slug',
				'terms'    => sanitize_text_field( $atts['term'] ),
			),
		);
	}

	// Execute the query
	$query = new WP_Query( $query_args );

	$output = '';

	// Display taxonomy filter buttons if taxonomy is set
	if ( ! empty( $atts['taxonomy'] ) && ! is_wp_error( $terms ) && count( $terms ) > 0 ) {
		$output .= '<div class="all-menu-filters">';
		$output .= '<button class="all-menu-filter-btn active" data-taxonomy="' . esc_attr( $atts['taxonomy'] ) . '" data-term="" data-post-type="' . esc_attr( $atts['post_type'] ) . '" data-orderby="' . esc_attr( $atts['orderby'] ) . '" data-order="' . esc_attr( $atts['order'] ) . '" data-posts-per-page="' . intval( $atts['posts_per_page'] ) . '" data-unique-id="' . esc_attr( $unique_id ) . '">All</button>';

		foreach ( $terms as $term ) {
			$active_class = ( ! empty( $atts['term'] ) && $atts['term'] === $term->slug ) ? 'active' : '';
			$output .= '<button class="all-menu-filter-btn ' . esc_attr( $active_class ) . '" data-taxonomy="' . esc_attr( $atts['taxonomy'] ) . '" data-term="' . esc_attr( $term->slug ) . '" data-post-type="' . esc_attr( $atts['post_type'] ) . '" data-orderby="' . esc_attr( $atts['orderby'] ) . '" data-order="' . esc_attr( $atts['order'] ) . '" data-posts-per-page="' . intval( $atts['posts_per_page'] ) . '" data-unique-id="' . esc_attr( $unique_id ) . '">' . esc_html( $term->name ) . '</button>';
		}

		$output .= '</div>';
	}

	// Posts container
	$output .= '<div class="custom-post-loop" id="' . esc_attr( $unique_id ) . '">';

	if ( $query->have_posts() ) {
		while ( $query->have_posts() ) {
			$query->the_post();
			$output .= '<div class="post-item">';
			$output .= '<h3>' . get_the_title() . '</h3>';
			$output .= '<p>' . get_the_excerpt() . '</p>';
			$output .= '<a href="' . get_the_permalink() . '">Read More</a>';
			$output .= '</div>';
		}
	} else {
		$output .= '<p>No posts found.</p>';
	}

	$output .= '</div>';

	// Reset post data
	wp_reset_postdata();

	return $output;
}

// AJAX handler for filtering posts
add_action( 'wp_ajax_all_menu_filter', 'all_menu_filter_ajax' );
add_action( 'wp_ajax_nopriv_all_menu_filter', 'all_menu_filter_ajax' );

/**
 * AJAX handler for filtering posts
 */
function all_menu_filter_ajax() {
	// Verify nonce
	if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( $_POST['nonce'], 'all_menu_nonce' ) ) {
		wp_send_json_error( 'Nonce verification failed' );
	}

	// Get POST data
	$post_type      = isset( $_POST['post_type'] ) ? sanitize_text_field( $_POST['post_type'] ) : 'post';
	$taxonomy       = isset( $_POST['taxonomy'] ) ? sanitize_text_field( $_POST['taxonomy'] ) : '';
	$term           = isset( $_POST['term'] ) ? sanitize_text_field( $_POST['term'] ) : '';
	$orderby        = isset( $_POST['orderby'] ) ? sanitize_text_field( $_POST['orderby'] ) : 'date';
	$order          = isset( $_POST['order'] ) ? sanitize_text_field( $_POST['order'] ) : 'DESC';
	$posts_per_page = isset( $_POST['posts_per_page'] ) ? intval( $_POST['posts_per_page'] ) : -1;

	// Build query arguments
	$query_args = array(
		'post_type'      => $post_type,
		'posts_per_page' => $posts_per_page,
		'orderby'        => $orderby,
		'order'          => $order,
	);

	// Add taxonomy filter if specified
	if ( ! empty( $taxonomy ) && ! empty( $term ) ) {
		$query_args['tax_query'] = array(
			array(
				'taxonomy' => $taxonomy,
				'field'    => 'slug',
				'terms'    => $term,
			),
		);
	}

	// Execute query
	$query = new WP_Query( $query_args );

	$output = '';

	if ( $query->have_posts() ) {
		while ( $query->have_posts() ) {
			$query->the_post();
			$output .= '<div class="post-item">';
			$output .= '<h3>' . get_the_title() . '</h3>';
			$output .= '<p>' . get_the_excerpt() . '</p>';
			$output .= '<a href="' . get_the_permalink() . '">Read More</a>';
			$output .= '</div>';
		}
	} else {
		$output .= '<p>No posts found.</p>';
	}

	wp_reset_postdata();

	wp_send_json_success( $output );
}
?>